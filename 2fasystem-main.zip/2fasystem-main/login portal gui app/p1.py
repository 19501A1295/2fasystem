import curl


def curl1():
    return curl.Curl('www.google.com')

print(curl1)